/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shuntingyard;

import java.util.LinkedList;

/**
 *
 * @author thegoodhen
 */
public class ByteNumberToken extends NumberToken{

	public ByteNumberToken(String s) {
		super(s);
	}
	
	@Override
	public void compile(LinkedList<Token> theStack, Compiler c) {
		theStack.push(this);
		c.getByteCode().push(new NumericByteCodeToken((byte)(this.getValue())));
	}

	@Override
	public int getNumberOfBytes() {
		return 1;
	}
}
