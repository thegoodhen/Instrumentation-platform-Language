/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shuntingyard;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author thegoodhen
 */
public class VariableAssignmentLineToken extends LineToken implements IRunnableToken {

	String variableString;
	String expressionString;
	Expression ex;
	private VariableToken targetVariable;

	public VariableAssignmentLineToken(String s) {
		super(s);
	}

	@Override
	public int getID() {
		return LineToken.VARIABLE_ASSIGNMENT;
	}

	@Override
	public String getRegex() {
		return "([A-Za-z][A-Za-z0-9]*)\\s*=\\s*(.+);";
		//return "([A-Za-z][A-Za-z0-9]*)\\s*=\\s*.+;";//TODO: use Variable.getRegex();
		//return "^(.*?=.*?);";
	}

	public void prepare(Compiler c) {

		Pattern pattern = Pattern.compile(this.getRegex());
		Matcher matcher = pattern.matcher(this.getTokenString());
		if (matcher.matches()) {
			variableString = matcher.group(1);
			//TODO: move this, we might not know the global variable yet...
			if (c.getCurrentFunction() != null) {
				targetVariable = c.getCurrentFunction().getLocalVariable(variableString);
			}
			if (targetVariable == null) {
				targetVariable = c.getGlobalVariable(variableString);
			}
			if (targetVariable == null) {
				System.err.println("Attempt to assign to a variable " + variableString + ", which is unknown in the current scope!");
			}
			expressionString = matcher.group(2);
			if (expressionString.equals(variableString)) {
				System.err.println("Expression assigns a variable to itself.");
			}
		}
	}

	public void precompile(Compiler c) {
		ex = c.getExpressionParser().createExpression(expressionString);
	}

	public void compile(Compiler c) {
		Token t = ex.compile(c);
		if (t instanceof IntegerNumberToken && targetVariable.getType() == VariableToken.BYTE) {
			System.err.println("Invalid assignment. Cannot assign an expression, result of which is an Integer, into a byte; this might lead to a lossy conversion.");
		} else if (t instanceof ByteNumberToken && targetVariable.getType() == VariableToken.INT) {
			//we need to cast the byte to int
			//TODO: centralize this
			//TODO: handle floats
			//CompilableToken.compileNumber(0,c);
			CompilableToken.compileByteToIntCast(0, c);
		}
		CompilableToken.compileNumber(this.targetVariable.getVariableID(), c);
		c.getByteCode().push(this);

	}

	@Override
	public void run(VirtualMachine vm) {
		int variableID = vm.popNumberFromStack(false);//TODO: somehow handle setExtended... So far we aren't supporting more than 256 bytes big heap!
		int assignedValue=0;
		switch (this.targetVariable.getContext()) {
			case VariableToken.GLOBAL:
				switch(this.targetVariable.getType())
				{
					case VariableToken.BYTE:
						assignedValue=vm.popByteFromStack();
						vm.getHeap().set(variableID, new NumericByteCodeToken((byte)assignedValue));
						break;
					case VariableToken.INT:
						assignedValue=vm.popIntFromStack();
						byte msb=HelpByteMethods.getUpperByte(assignedValue);
						byte lsb=HelpByteMethods.getLowerByte(assignedValue);
						vm.getHeap().set(variableID, new NumericByteCodeToken(msb));
						vm.getHeap().set(variableID+1, new NumericByteCodeToken(lsb));
						break;
						//TODO: handle float!
				}
				break;
				//TODO: handle local and argument!
		}
		//System.out.println("Assigned value "+assignedValue+" to "+this.targetVariable.getTokenString()+"!");

	}
}
