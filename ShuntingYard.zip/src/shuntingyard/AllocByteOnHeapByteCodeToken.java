/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shuntingyard;

/**
 *
 * @author thegoodhen
 */
public class AllocByteOnHeapByteCodeToken extends ByteCodeToken implements IRunnableToken{

	@Override
	public void run(VirtualMachine vm) {
		int bytesToAllocCount=vm.popNumberFromStack(this.getExtended());



		for(int i=0;i<bytesToAllocCount;i++)
		{
			vm.getHeap().add(new NumericByteCodeToken((byte)0));
		}
	}
	
}
