/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shuntingyard;

/**
 *
 * @author thegoodhen
 */
public class NumberTokenFactory extends TokenFactory {

	public NumberTokenFactory() {

	}


	@Override
	public String getRegex() {
		return  "[0-9][0-9]*";
	}

	@Override
	public Token generateInstance(String tokenString) {
		int value;
		try {

			value = Integer.parseInt(tokenString);
			if(value<256)
			{
				return new ByteNumberToken(tokenString);
			}
			else
			{
				return new IntegerNumberToken(tokenString);//TODO: handle float too
			}
		}
		catch(Exception e)
		{
			System.err.println("Factory encountered a request to create a numeric token from a string, but the given string \""+tokenString+ "\" doesn't represent a valid numeric token");
		}
		return null;//new NumberToken(tokenString);
	}

}
