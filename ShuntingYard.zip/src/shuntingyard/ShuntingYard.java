/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shuntingyard;

import java.util.ArrayList;

/**
 *
 * @author thegoodhen
 */
public class ShuntingYard {

	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {
// ... the code being measured ...    
		ExpressionParser p = new SimpleParser();
		//p.parse("+323");"2*5-2+(2+4)*2"
		ArrayList<Token> tokenList=p.Tokenize("(2*(x+12)+3)");//p.Tokenize("(5+3)*12/3");//p.Tokenize("3+4");//p.Tokenize("slepice09+(2*kokon(2,3))+10/2");
		ArrayList<Token> rpn =p.getRPN(tokenList);
		for(Token t:rpn)
		{
			System.out.println(t.tokenString);
		}

		//ExpressionParser p2=new SimpleLineParser();
		//String prog="byte kokodak;\n int slepice;\nslepice=500;\nslepice(slepice(1,2),slepice(3,4));\nkokodak=5+1;\nIF (kokodak)\nELSE\nENDIF\n byte slepice(byte bl, int b2)\n  byte pipka;\nint i;\nkokodak=0;\nFOR i=10; i;i=i+1;\n pipka=pipka+1; \nNEXT\n\nRETURN pipka;\nENDFUNCTION\n";
		//String prog="byte kokodak;\nint slepice;\nslepice=500;\nslepice1(slepice1(10,10),10);\nkokodak=5+1;\nIF (kokodak)\nELSE\nENDIF\n int slepice1(byte bl, int b2)\n  byte pipka;\nint i;\nkokodak=0;\nFOR i=10; i;i=i+1;\n pipka=pipka+1; \nNEXT\n\nRETURN pipka;\nENDFUNCTION\n";
		//String prog="byte kokodak;\nint slepice;\nslepice=500;\nslepice1(slepice1(90));\nkokodak=5+1;\nIF (kokodak)\nELSE\nENDIF\nint slepice1(byte bl)\n  int pipka;\nint i;\nkokodak=0;\nFOR i=10; i;i=i+1;\n pipka=pipka+1; \nNEXT\n\nRETURN pipka;\nENDFUNCTION\n";
		//tokenList=p2.Tokenize(prog);

		//String prog="byte kokodak;\nbyte slepice;\nslepice=3;\nkokodak=5;\n";//OK
		//String prog="byte kokodak;\n int slepice;\nslepice=3;\nkokodak=5;\n";
		//String prog="byte kokodak;\nkokodak=3;\nIF(kokodak)\nkokodak=10;\nELSE\nkokodak=5;\nENDIF\nkokodak=5;\n";
		//String prog="byte a;\n byte b;\nbyte kokon(byte parametr)\nRETURN parametr+1;\n ENDFUNCTION\n";
		//String prog="byte a;\n byte b;\nbyte kokon(byte parametr, byte param)\nint a; \na=10;\nRETURN parametr+1;\n ENDFUNCTION\n";
		//String prog="byte a;\nIF (10)\na=0;\nENDIF\nIF (5)\n\na=1;\nENDIF\n";
		//String prog="byte kokodak;\nIF (10)\nIF(5)\nkokodak=1;\nENDIF\nENDIF\n";
		//String prog="byte kokon;\nFOR kokon=10;kokon;kokon=kokon-1;\nbyte slepiceFluf;\nslepiceFluf=slepiceFluf+1;\nNEXT\n";
		//String prog="byte kokon;\nFOR kokon=0;kokon<=10;kokon=kokon+1;\nbyte slepiceFluf;\nslepiceFluf=slepiceFluf+1;\nNEXT\n";

		//String prog="byte kokon;\nbyte slepice;\n\nkokon=5;\nprintNumber(15);\nprintNumber(20);\nIF (kokon>=3 && kokon<=5)\nslepice=3;\nELSE\nslepice=2;\nENDIF\n";

		String prog="byte slepice;\nFOR slepice=0;slepice<10;slepice=slepice+1;\nprintNumber(slepice*2);\nNEXT\n";

		Compiler c=new Compiler();
		c.compile(prog);
		VirtualMachine vm=new VirtualMachine();
		vm.setProgram(c.getByteCodeAL());
		vm.runProgram();
		
		/*
		for(Token t:tokenList)
		{
			System.out.println(t.getClass().getSimpleName());
			System.out.println(t.tokenString);
		}
			*/
//long startTime = System.nanoTime();    
//p.parse(rpn);
		//System.out.println(p.parse(rpn).getTokenString());
//long estimatedTime = System.nanoTime() - startTime;
//System.out.println(estimatedTime);
			

	}
	
}
