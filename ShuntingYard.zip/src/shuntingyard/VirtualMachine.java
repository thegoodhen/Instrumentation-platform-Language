/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shuntingyard;

import java.util.ArrayList;
import java.util.LinkedList;

/**
 *
 * @author thegoodhen
 */
public class VirtualMachine {
	//TODO: decide on the actual list type for stack and heap
	private LinkedList<Token> programStack=new LinkedList<>();
	private ArrayList<NumericByteCodeToken> programHeap=new ArrayList<>();
	private int programCounter;
	private ArrayList<Token> program;
	private boolean isStopped=false;

	public void stop()
	{
		this.isStopped=true;
	}

	public LinkedList<Token> getStack()
	{
		return this.programStack;
	}

	public ArrayList<NumericByteCodeToken> getHeap()
		{
			return this.programHeap;
		}

	public byte popByteFromStack() throws RuntimeException
	{
		return ((NumericByteCodeToken)(this.programStack.pop())).getValue();
	}

	public int popIntFromStack() throws RuntimeException
	{
		byte lsb=((NumericByteCodeToken)(this.programStack.pop())).getValue();
		byte msb=((NumericByteCodeToken)(this.programStack.pop())).getValue();

		return HelpByteMethods.constructInt(msb, lsb);
	}

	public void pushByteOnStack(byte b)
	{
		this.programStack.push(new NumericByteCodeToken(b));
	}
	public void pushIntOnStack(int i)
	{
		byte msb=HelpByteMethods.getUpperByte(i);
		byte lsb=HelpByteMethods.getLowerByte(i);
		this.programStack.push(new NumericByteCodeToken(msb));
		this.programStack.push(new NumericByteCodeToken(lsb));
	}

	public void pushNumberOnStack(int number, boolean extended)
	{
		if(extended)
		{
			pushIntOnStack(number);
		}
		else
		{
			pushByteOnStack((byte)number);
		}
	}

	public int popNumberFromStack(boolean extended)
	{
		if(extended)
		{
			return this.popIntFromStack();
		}
		else
		{
			return this.popByteFromStack();
		}
	}

	public int getProgramCounter()
	{
		return this.programCounter;
	}

	public void setProgramCounter(int programCounter)
	{
		this.programCounter=programCounter;
	}

	public void relativeJump(int howMuch)
	{
		this.programCounter+=howMuch-1;// -1, cause of the way we are iterating over the elements in runProgram. We jump to one before where we want to jump, and the progCounter icrements itself in runProgram.
	}

	public void setProgram(ArrayList<Token> program)
	{
		this.program=program;
	}

	public void runProgram()
	{
		this.isStopped=false;
		programCounter=0;
		while(!isStopped)
		{
			Token t=program.get(programCounter);
			if(t instanceof IRunnableToken)
			{
				((IRunnableToken)(t)).run(this);
			}
			programCounter++;
		}
	}
	
}
