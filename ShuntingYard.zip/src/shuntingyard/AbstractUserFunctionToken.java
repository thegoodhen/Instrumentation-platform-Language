/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shuntingyard;

/**
 *
 * @author thegoodhen
 */
public abstract class AbstractUserFunctionToken extends FunctionToken implements IRunnableToken{

	public AbstractUserFunctionToken(String tokenString) {
		super(tokenString);
	}



	protected void doLookup(Compiler c)
	{
		//do nothing?
	}

	@Override
	protected void compileCall(Compiler c)
	{
		c.getByteCode().push(this);
	}


	
}
