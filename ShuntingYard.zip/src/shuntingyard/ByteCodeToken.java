/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shuntingyard;

/**
 *
 * @author thegoodhen
 */
public class ByteCodeToken extends Token{

	private boolean extended;
	@Override
	public int getID() {
		throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
	}

	@Override
	public String getRegex() {
		return "";
	}

	public void setExtended(boolean extended)
	{
		this.extended=extended;
	}

	public boolean getExtended()//TODO: rename to isExtended?
	{
		return this.extended;
	}

	
}
