/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shuntingyard;

import java.util.ArrayList;

/**
 * Abstraction for classes that use a factory to generate a stream of Tokens
 * from a String.
 *
 * @author thegoodhen
 */
public class AbstractParser {

	private TokenFactory tf;
	private int currentIndex = 0;
	private int tokenNumber = 0;

	public AbstractParser() {
		tf = new GeneralTokenFactory();
	}

	public void setFactory(TokenFactory tf) {
		this.tf = tf;
	}

	public void parsingError(int tokenNumber) {

		System.err.println("Unknown token: "+tokenNumber+" Parser exiting!");
	}

	/**
	 * Turn a string representing an expression written in infix notation
	 * with function calls into an ArrayList of Token objects. This method
	 * makes calls to the set tokenFactory.
	 *
	 * @param s the String to generate an arrayList of tokens from
	 * @return ArrayList of Tokens, generated from the input String
	 */
	public ArrayList<Token> Tokenize(String s) {
		//System.out.println(startsWithRegex(s,"[+-/*//><=]"));
		//System.out.println(getTokenEnd(s,"[+-/*//><=]",0));
		//System.out.println(getTokenEnd(s,"([A-Za-z][A-Za-z0-9]*).*",0));
//([A-Za-z][A-Za-z0-9]*).*
		//s = stripSpaces(s);
		currentIndex = 0;
		tokenNumber=0;
		ArrayList<Token> returnList = new ArrayList<>();

		while (currentIndex < s.length()) {
			//String tokenString = crunchToken(s);
			Token t = tf.create(s, currentIndex);
			if (t == null) {
				parsingError(tokenNumber);
				break;
			}
			currentIndex = tf.getRegexEnd();
			//Token t = tf.create(lastTokenID, tokenString);
			returnList.add(t);
			tokenNumber++;
			//System.out.println(t.getTokenString());
			//System.out.println(crunchToken(s));
		}
		return returnList;
	}

}
