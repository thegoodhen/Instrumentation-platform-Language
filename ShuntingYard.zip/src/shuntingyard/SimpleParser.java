/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shuntingyard;

/**
 *
 *This class is now deprecated. It does not differ from its superclass in any way.
 * @author thegoodhen
 */
public class SimpleParser extends ExpressionParser{
	public SimpleParser()
	{
		super();
		/*
		this.addToken(new NumberToken("0"));
		this.addToken(new LeftBracketToken(""));
		this.addToken(new RightBracketToken(""));
		this.addToken(new ArgumentSeparatorToken(""));
		this.addToken(new FunctionToken(""));
		this.addToken(new VariableToken(""));
		this.addToken(new OperatorTokenImpl(""));
			*/
	}
	
}
