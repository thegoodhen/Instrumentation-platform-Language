/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shuntingyard;

/**
 *
 * @author thegoodhen
 */
public class AssignmentOperatorToken extends OperatorToken{

	public AssignmentOperatorToken(String s) {
		super(s);
	}

	@Override
	public int getPriority()
	{
		return -100;//maybe lower
	}
	
	@Override
	public float computeBinaryOperatorFromNumbers(float a, float b) {
		return a;
	}

	public int getAssociativity() {
		return ASSOCIATIVITY_RIGHT;
	}

	@Override
	public int getArgumentCount() {
		return 2;
	}

	public void compile(Compiler c)
	{

	}
}
