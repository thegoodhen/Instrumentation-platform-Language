/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shuntingyard;

import java.util.LinkedList;

/**
 *
 * @author thegoodhen
 */
public class VariableToken extends CompilableToken {

	public static final int UNKNOWN = -1;
	public static final int BYTE = 0;
	public static final int INT = 1;//TODO: add float
	public static final int VOID = 2;//TODO: add float



	public static final int GLOBAL=0;
	public static final int LOCAL=1;
	public static final int PARAM=2;

	int variableID;
	private int type;
	private int context;

	VariableToken(String tokenString) {
		super(tokenString);
		this.type = UNKNOWN;
		this.context = UNKNOWN;
	}

	public void setGlobal()
	{
		this.context=GLOBAL;
	}

	public void setLocal()
	{
		this.context=GLOBAL;
	}

	public void setParam()
	{
		this.context=PARAM;
	}

	public int getContext()
	{
		return this.context;
	}

	public int getType() {
		return this.type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public int getVariableID() {
		return this.variableID;
	}

	public void setVariableID(int variableID) {
		this.variableID = variableID;
	}

	@Override
	public int getID() {
		return Token.VARIABLE;
	}

	@Override
	public String getRegex() {
		return "([A-Za-z][A-Za-z0-9]*)";
	}

	//TODO: put the getNumberOfBytes into an interface.
	public int getNumberOfBytes()
	{
		if(this.type==BYTE)
		{
			return 1;
		}
		else if(this.type==INT)
		{
			return 2;
		}
		//TODO: refactor; handle floats
		return -1;
	}

	@Override
	public void compile(LinkedList<Token> theStack, Compiler c) {
		//figure out if this variable even exists

		VariableToken vt;
		if (c.getCurrentFunction() == null) {
			vt = c.getGlobalVariable(this.getTokenString());
		} else {
			vt = c.getCurrentFunction().getLocalVariable(this.getTokenString());
		}
		if(vt==null)
		{
			vt=c.getCurrentFunction().getParameter(this.getTokenString());
		}

		if (vt == null) {
			System.err.println("The variable \"" + this.getTokenString() + "\" cannot be used in an expression, as it is not a known variable in the current context!");
		} else {
			NumberTokenFactory ntf = new NumberTokenFactory();

			NumberToken nt = (NumberToken) ntf.create(Integer.toString(vt.getVariableID()), 0);
			nt.compile(theStack, c);//when we compile the variable, we add the ID of the variable on the bytecode stack of the compiler c. We use NumberTokenFactory to decide, whether the ID is actually 1 byte long or 2 bytes long and then we add those bytes to the compiler bytecode stack.
			theStack.pop();//well... the previous call had the side effect of placing the "NumberToken" on the working stack "theStack", which is not what we want, so we're removing it from the working stack here!

			boolean extended = false;

			if (nt instanceof ByteNumberToken) {
				extended = false;
			} else {
				extended = true;
			}

			this.type = vt.getType();
			this.context=vt.getContext();

			if (this.getType() == BYTE) {
				c.getByteCode().push(new PushByteVariableOnStackByteCodeToken(extended));
				theStack.push(new ByteNumberToken("0"));
			} else if (this.getType() == INT) {
				c.getByteCode().push(new PushIntegerVariableOnStackByteCodeToken(extended));
				theStack.push(new IntegerNumberToken("0"));
			} else {
				System.err.println("Cannot compile a variable reference; unknown variable type for variable \"" + this.getTokenString() + ".\"");

			}
		}

	}

}
