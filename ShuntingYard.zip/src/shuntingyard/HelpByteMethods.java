/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shuntingyard;

/**
 *
 * @author thegoodhen
 */
public class HelpByteMethods {

	public static byte getLowerByte(int value) {
		return (byte) value;
	}

	public static byte getUpperByte(int value) {
		return (byte) (value >> 8);
	}

	public static int constructInt(byte msb, byte lsb)
	{
		return (((msb & 0xff) << 8) | lsb); 
	}
	
}
