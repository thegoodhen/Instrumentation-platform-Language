/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shuntingyard;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;

/**
 *
 * @author thegoodhen
 */
public class Compiler {

	HashMap<String, VariableToken> globalVariablesMap = new HashMap();
	HashMap<String, FunctionToken> functionMap = new HashMap();
	ExpressionParser p = new SimpleParser();
	LineParser lp = new SimpleLineParser();
	LinkedList<Token> byteCode; //TODO: see if we could use ArrayList to improve the speed of get()
	ArrayList<Token> linesList;
	private FunctionToken currentFunction;
	ArrayList<Token> byteCodeAL = new ArrayList<>();


	public Compiler() {
		this.byteCode = new LinkedList<>();
	}

	ArrayList<Token> getLines() {
		return this.linesList;
	}

	public ExpressionParser getExpressionParser() {
		return p;
	}

	public LinkedList<Token> getByteCode() {
		return this.byteCode;
	}

	public ArrayList<Token> getByteCodeAL()
	{
		return this.byteCodeAL;
	}

	public VariableToken getGlobalVariable(String name) {
		return globalVariablesMap.get(name);
	}

	public FunctionToken getFunction(String name) {
		return functionMap.get(name);
	}

	public void addGlobalVariable(VariableToken v) {
		System.out.println("Adding a global variable: " + v.tokenString);
		v.setVariableID(this.getGlobalVariableByteCount());
		v.setGlobal();
		globalVariablesMap.put(v.getTokenString(), v);
	}

	public void addFunction(FunctionToken f) {
		System.out.println("Adding a function: " + f.getTokenString());
		//int numberOfElementsInMap=globalVariablesMap.size();//TODO: id should correspond to the heap location
		//v.setVariableID(numberOfElementsInMap);
		functionMap.put(f.getTokenString(), f);
	}

	public void compile(String s) {
		linesList = lp.Tokenize(s);
		firstPass(linesList);
		boolean ex = CompilableToken.compileNumber(getGlobalVariableByteCount(), this);
		AllocByteOnHeapByteCodeToken abohbct = new AllocByteOnHeapByteCodeToken();
		abohbct.setExtended(ex);
		getByteCode().push(abohbct);
		secondPass(linesList);
		thirdPass(linesList);

		for (int i = byteCode.size() - 1; i >= 0; i--)//hotfix here, slows everything down, should be fixed soon!
		{
			byteCodeAL.add(byteCode.get(i));
		}
		byteCodeAL.add(new NoOperationByteCodeToken());
		byteCodeAL.add(new StopByteCodeToken());

		boolean everyJumpResolved = false;
		while (!everyJumpResolved) {
			ArrayList<Token> byteCodeCopy = (ArrayList<Token>) byteCodeAL.clone();//shallow copy to avoid ConcurrentModificationException
			everyJumpResolved = true;
			for (Token t : byteCodeAL) {
				if (t instanceof AbstractJumpByteCodeToken) {
					boolean recompiled = (((AbstractJumpByteCodeToken) t).updateTargetInfo(byteCodeCopy));
					if (recompiled) {
						everyJumpResolved = false;
					}
				}
			}
			byteCodeAL = byteCodeCopy;
		}

		if (byteCode.isEmpty());
		System.out.println("konec");
	}

	private void firstPass(ArrayList<Token> al) {
		for (Token t : al) {
			((LineToken) t).prepare(this);
		}

	}

	private void secondPass(ArrayList<Token> al) {

		for (Token t : al) {
			((LineToken) t).precompile(this);
		}
	}

	private void thirdPass(ArrayList<Token> al) {

		for (Token t : al) {
			((LineToken) t).compile(this);
		}
	}

	public void issueWaring(String s) {
		System.err.println(s);
	}

	public void setCurrentFunction(FunctionToken ft)//TODO: throw runtimeException when this is called outside the compilation stage!
	{
		this.currentFunction = ft;
	}

	public FunctionToken getCurrentFunction() {
		return this.currentFunction;
	}

	private int getGlobalVariableByteCount() {
		int returnNumber = 0;
		for (Token t : globalVariablesMap.values()) {
			if (t instanceof VariableToken) {
				returnNumber += ((VariableToken) t).getNumberOfBytes();
			}
		}
		return returnNumber;
	}

}
