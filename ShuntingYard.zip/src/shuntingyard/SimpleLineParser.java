/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shuntingyard;

/**
 * @author thegoodhen
 */
@Deprecated
public class SimpleLineParser extends LineParser {

	public SimpleLineParser() {
		super();
		/*
		 this.addToken(new IfLineToken(""));
		 this.addToken(new ElseLineToken(""));
		 this.addToken(new EndIfLineToken(""));
		 this.addToken(new VariableDeclarationLineToken(""));
		 this.addToken(new FunctionDeclarationLineToken(""));
		 this.addToken(new EndFunctionLineToken(""));
		 this.addToken(new VariableAssignmentLineToken(""));
		 */
	}

}
