/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shuntingyard;

import java.util.LinkedList;

/**
 *TODO: change name to ExpressionToken?
 * @author thegoodhen
 */
public abstract class CompilableToken extends Token {

	int argumentCount = 0;

	public CompilableToken(String s) {
		super(s);
	}

	public int getArgumentCount() {
		return this.argumentCount;
	}


	/**
	 * Add 1 or two bytes representing the given number to the specified compilers ByteCode.
	 * If the number given is less than 256, greather than or equal to 0 (e.g. can be represented by a byte), only this single
	 * byte is placed on top of the ByteCode stack of the compiler c. In other cases, the integer
	 * is split into two bytes, and those are placed on the top of the ByteCode stack, MSB first.
	 * @param number the number to place on the Compiler stack
	 * @param c the compiler, stack of which should be used
	 * @return whether 2 bytes were placed on the stack (true) or just one (false);
	 */
	public static boolean compileNumber(int number, Compiler c) {

		boolean returnVal=false;
		byte lowerByte = (byte) (number & 0xFF);
		byte upperByte = (byte) ((number >> 8) & 0xFF);
		if (number > 255 && number>=0) {
			c.getByteCode().push(new NumericByteCodeToken(upperByte));
			returnVal=true;
		}
		c.getByteCode().push(new NumericByteCodeToken(lowerByte));
		return returnVal;
	}



/**
 * Compile the command to cast nth byte on the stack to integer. The topmost byte is number 0.
 * @param index
 * @param c 
 */
	public static void compileByteToIntCast(int index, Compiler c)
	{
			compileNumber(index,c);
			c.getByteCode().push(new CastToIntegerByteCodeToken());
	}

	/**
	 * Compile this token, popping the required arguments from stack,
	 * returning the symbolic result on stack. The result is a Token,
	 * describing the symbolic return value of the token, corresponding to
	 * the actual return value if computed in runtime. For instance, if this
	 * class is extended by a function, it should pop n arguments from the
	 * stack, where n is the number of arguments to the function, and should
	 * place such token on the stack, that it represents the return type of
	 * the function (such as byteNumberToken) Please note that this is a
	 * class designed to be extended by operators/functions or other tokens
	 * that can be compiled. It's not to be used for variables or literals.
	 * The generic contract for this function is that it MUST ensure that
	 * the amount of elements popped from the stack does not exceed the
	 * number indicated by
	 *
	 * @see getArgumentCount()
	 * @param theStack
	 * @param c the compiler to give the resulting bytecode to
	 */
	public abstract void compile(LinkedList<Token> theStack, Compiler c);
}
