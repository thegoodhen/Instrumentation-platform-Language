/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shuntingyard;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author thegoodhen
 */
public class ReturnLineToken extends LineToken {

	private String expressionString;
	private FunctionDeclarationLineToken fdlt;
	private Expression ex;
	private boolean extendedArgumentCount=false;//whether the number of arguments of the function this return statement belong to is over 255 (more than 1 byte)

	public ReturnLineToken(String s) {
		super(s);
	}

	@Override
	public int getID() {
		return LineToken.IF;
	}

	public FunctionDeclarationLineToken getFunctionDeclaration() {
		return this.fdlt;
	}

	public void setFunctionDeclaration(FunctionDeclarationLineToken fdlt)
	{
		this.fdlt=fdlt;
	}

	public void prepare(Compiler c) {

		Pattern pattern = Pattern.compile(this.getRegex());
		Matcher matcher = pattern.matcher(this.getTokenString());
		if (matcher.matches()) {
			expressionString = matcher.group(1);
		}

		if(this.fdlt==null)
		{
			System.err.println("Error: return statement outside function is invalid.");
		}
	}

	public void precompile(Compiler c) {
		ex = c.getExpressionParser().createExpression(expressionString);
	}

	public void compile(Compiler c) {
		Token t = ex.compile(c);
		if(t instanceof NumberToken)
		{
			//TODO: centralize the casting
			//TODO: handle floats
			if(t instanceof IntegerNumberToken)
			{
				if(this.fdlt.getFunction().getReturnType()==VariableToken.BYTE)//expression is int, should return byte
				{
					System.err.println("Incompatible return values: actual and formal return types differ, and no implicit conversion exists!");
				}
			}
			else if(t instanceof ByteNumberToken)//expression is a byte, should return int
			{
				if(this.fdlt.getFunction().getReturnType()==VariableToken.INT)
				{
					CompilableToken.compileByteToIntCast(0, c);
				}
			}
		}
		else
		{
			System.err.println("Invalid return type.");
		}
		this.extendedArgumentCount=CompilableToken.compileNumber(this.fdlt.getFunction().getArgumentByteCount(), c);
		c.getByteCode().push(this);


	}

	@Override
	public String getRegex() {//TODO: I have to do something about this; this object doesn't have a 
		//reference to the Factory creating it; the Factory needs to know the Regex. This leads to 
		//code duplication, since sometimes (like in this case) we have to know the Regex 
		//both in the Factory AND in the Token. The getRegex() method isn't static, so if we wanted to remotely call it from the Factory, we'd need to instantiate the Token in the factory; this could be done in the constructor of the said Factory.

		return "RETURN\\s+(.*)\\s*;";
		//return "^IF\\s+(.*)$";
		//return "^(.*?=.*?);";
	}

}
