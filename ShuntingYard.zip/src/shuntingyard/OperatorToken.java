/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shuntingyard;

import java.util.LinkedList;

/**
 *
 * @author thegoodhen
 */
public abstract class OperatorToken extends CompilableToken implements IRunnableToken{

	public final static int ASSOCIATIVITY_LEFT = 0;
	public final static int ASSOCIATIVITY_RIGHT = 1;
	private int operandType = VariableToken.UNKNOWN;

	public OperatorToken(String s) {
		super(s);
	}

	@Override
	public int getID() {
		return Token.OPERATOR;
	}

	@Override //TODO: make this static, ditch the override, make the regex subject to change
	public String getRegex() {
		return "(\\+|-|==|=|\\/|\\*)";
		//return  "[\\+-/*\\\\/]";
	}
	

	public int getPriority() {
		return -1;
	}

	public int getAssociativity() {
		return ASSOCIATIVITY_LEFT;
	}

	@Override
	public int getArgumentCount() {
		return 2;
	}

	@Override
	public void compile(LinkedList<Token> theStack, Compiler c) {
		//first we get the 2 operands off our working stack
		Token o1=null;
		Token o2=null;
		
		if (theStack.size() >= 2) {
			o1 = theStack.pop();
			o2 = theStack.pop();
		}
		else
		{
			System.err.println("Not enough arguments to an operator: \""+this.getTokenString()+"\"");
		}
		//Then we make sure those are actually numbers; if not, this is not RPN!
		if (!(o1 instanceof NumberToken && o2 instanceof NumberToken)) {
			System.err.println("Expected numeric arguments or variables for an operator; Operator" + this.getTokenString() + " cannot be applied to arguemnts of type" + o1.getClass().getSimpleName() + " and " + o2.getClass().getSimpleName() + "!");
		} else if (o1 instanceof ByteNumberToken && o2 instanceof ByteNumberToken) {
			this.operandType = VariableToken.BYTE;
		} else if (o1 instanceof IntegerNumberToken && o2 instanceof IntegerNumberToken) {
			this.operandType = VariableToken.INT;
		} else if (o1 instanceof ByteNumberToken && o2 instanceof IntegerNumberToken) {
			this.operandType = VariableToken.INT;
			compileNumber(0, c);
			c.getByteCode().push(new CastToIntegerByteCodeToken());
		} else if (o1 instanceof IntegerNumberToken && o2 instanceof ByteNumberToken) {
			this.operandType = VariableToken.INT;
			compileNumber(2, c);
			c.getByteCode().push(new CastToIntegerByteCodeToken());
		}
		if (this.operandType == VariableToken.BYTE) {
			theStack.push(new ByteNumberToken("0"));
		} else if (this.operandType == VariableToken.INT) {
			theStack.push(new IntegerNumberToken("0"));
		}
		c.getByteCode().push(this);
	}

	//@Override
	public NumberToken compute(LinkedList<Token> theStack) {
		if (theStack.size() < getArgumentCount()) {
			System.err.println("Not enough arguments on stack!");
		}
		Token t1 = theStack.pop();
		Token t2 = theStack.pop();
		if (t1 instanceof NumberToken && t2 instanceof NumberToken)//TODO: support variables
		{
			int newVal = (int)computeBinaryOperatorFromNumbers(((NumberToken) t1).getValue(), ((NumberToken) t2).getValue());
			NumberTokenFactory ntf = new NumberTokenFactory();
			NumberToken t3 = (NumberToken) ntf.create(Integer.toString(newVal), 0);//new NumberToken(Integer.toString(newVal));

			theStack.push(t3);
			return t3;
		}
		System.err.println("Cannot compute operator, expected numeric arguments");
		return null;
	}

	public abstract float computeBinaryOperatorFromNumbers(float a, float b);



	@Override
	public void run(VirtualMachine vm)
	{
		switch(this.operandType)
		{
			//TODO: handle float!

			//unhandled exceptions below, but those couldn't be recovered from anyway and would be unexpected!
			case VariableToken.BYTE:
				NumericByteCodeToken o2=(NumericByteCodeToken) vm.getStack().pop();
				NumericByteCodeToken o1=(NumericByteCodeToken) vm.getStack().pop();
				byte ret=(byte) computeBinaryOperatorFromNumbers(o1.getValue(),o2.getValue());
				vm.getStack().push(new NumericByteCodeToken(ret));
				break;
			case VariableToken.INT:
				NumericByteCodeToken o2lsb=(NumericByteCodeToken) vm.getStack().pop();
				NumericByteCodeToken o2msb=(NumericByteCodeToken) vm.getStack().pop();
				int o2int=HelpByteMethods.constructInt(o2msb.getValue(), o2lsb.getValue());
				NumericByteCodeToken o1lsb=(NumericByteCodeToken) vm.getStack().pop();
				NumericByteCodeToken o1msb=(NumericByteCodeToken) vm.getStack().pop();
				int o1int=HelpByteMethods.constructInt(o2msb.getValue(), o2lsb.getValue());
				int ret2=(int) (computeBinaryOperatorFromNumbers(o1int,o2int));
				byte retMsb=HelpByteMethods.getUpperByte(ret2);
				byte retLsb=HelpByteMethods.getLowerByte(ret2);
				vm.getStack().push(new NumericByteCodeToken(retMsb));
				vm.getStack().push(new NumericByteCodeToken(retLsb));
				break;
		}
	}

}
