/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shuntingyard;

/**
 *
 * @author thegoodhen
 */
public class NumberToken extends Token{

	int value=0;


	public NumberToken(String s)
	{
		super(s);
		value=Integer.parseInt(s);
	}
	
	public Integer getValue()
	{
		return this.value;
	}

	@Override
	public String getRegex()
	{
		return  "[0-9][0-9]*";
	}
	@Override
	public int getID() {
		return Token.NUMBER;
	}
	
}
