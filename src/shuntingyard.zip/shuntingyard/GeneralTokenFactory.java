package shuntingyard;


import java.util.HashMap;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author thegoodhen
 */
public class GeneralTokenFactory implements TokenFactory{
	HashMap<Integer,TokenFactory> subFactoryMap;
	public GeneralTokenFactory()
	{
		subFactoryMap=new HashMap();
		subFactoryMap.put(Token.NUMBER, new NumberTokenFactory());
		subFactoryMap.put(Token.LEFTBRACKET, new LeftBracketFactory());
		subFactoryMap.put(Token.RIGHTBRACKET, new RightBracketFactory());
		subFactoryMap.put(Token.ARGUMENTSEPARATOR, new ArgumentSeparatorTokenFactory());
		subFactoryMap.put(Token.FUNCTIONCALL, new FunctionTokenFactory());
		subFactoryMap.put(Token.VARIABLE, new VariableTokenFactory());
		subFactoryMap.put(Token.OPERATOR, new OperatorTokenFactory());
	}
	public Token create(int tokenID, String tokenString)
	{
		return subFactoryMap.get(tokenID).create(tokenID, tokenString);
	}
	
}
