/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shuntingyard;

import java.util.LinkedList;

/**
 *
 * @author thegoodhen
 */
public abstract class OperatorToken extends ComputableToken{

	public final static int ASSOCIATIVITY_LEFT=0;
	public final static int ASSOCIATIVITY_RIGHT=1;

	public OperatorToken(String s)
	{
		super(s);
	}

	@Override
	public int getID() {
		return Token.OPERATOR;
	}

	@Override
	public String getRegex() {
		return  "[\\+-/*\\\\/]";
	}

	public int getPriority()
	{
		return -1;
	}

	public int getAssociativity()
		{
			return ASSOCIATIVITY_LEFT;
		}
	
	@Override
	public int getArgumentCount()
{
	return 2;
}

	@Override
	public NumberToken compute(LinkedList<Token> theStack) {
		if(theStack.size()<getArgumentCount())
		{
			System.err.println("Not enough arguments on stack!");
		}
		Token t1=theStack.pop();
		Token t2=theStack.pop();
		if(t1 instanceof NumberToken && t2 instanceof NumberToken)//TODO: support variables
		{
			int newVal=computeBinaryOperatorFromNumbers(((NumberToken)t1).getValue(),((NumberToken)t2).getValue());
			NumberToken t3=new NumberToken(Integer.toString(newVal));

			theStack.push(t3);
		return t3;
		}
		System.err.println("Cannot compute operator, expected numeric arguments");
		return null;
	}


public abstract int computeBinaryOperatorFromNumbers(int a, int b);

}
