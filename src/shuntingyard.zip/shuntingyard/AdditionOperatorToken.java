/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shuntingyard;

import java.util.LinkedList;

/**
 *
 * @author thegoodhen
 */
public class AdditionOperatorToken extends OperatorToken{

	AdditionOperatorToken(String tokenString) {
		super(tokenString);
	}
	
	@Override
	public int getPriority()
	{
		return 10;
	}

	@Override
	public int computeBinaryOperatorFromNumbers(int a, int b) {
		return a+b;
	}

}