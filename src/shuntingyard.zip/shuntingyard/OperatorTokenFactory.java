/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shuntingyard;

import java.util.HashMap;

/**
 *
 * @author thegoodhen
 */
public class OperatorTokenFactory implements TokenFactory{
	HashMap<String,TokenFactory> subOperatorFactoryMap;

	public OperatorTokenFactory()
	{
		subOperatorFactoryMap=new HashMap<>();
		subOperatorFactoryMap.put("+", new AdditionOperatorTokenFactory());
		subOperatorFactoryMap.put("-", new SubtractionOperatorTokenFactory());
		subOperatorFactoryMap.put("*", new MultiplicationOperatorTokenFactory());
		subOperatorFactoryMap.put("/", new DivisionOperatorTokenFactory());
	}
	
	public Token create(int tokenID, String tokenString) {
		return subOperatorFactoryMap.get(tokenString).create(tokenID, tokenString);
	}
	
}
