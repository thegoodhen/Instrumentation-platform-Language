/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shuntingyard;

import java.util.ArrayList;

/**
 *
 * @author thegoodhen
 */
public class ShuntingYard {

	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {
// ... the code being measured ...    
		Parser p = new SimpleParser();
		//p.parse("+323");"2*5-2+(2+4)*2"
		ArrayList<Token> tokenList=p.Tokenize("(2+2)*3-1");//p.Tokenize("(5+3)*12/3");//p.Tokenize("3+4");//p.Tokenize("slepice09+(2*kokon(2,3))+10/2");
		ArrayList<Token> rpn =p.getRPN(tokenList);
//long startTime = System.nanoTime();    
p.parse(rpn);
		System.out.println(p.parse(rpn).getTokenString());
//long estimatedTime = System.nanoTime() - startTime;
//System.out.println(estimatedTime);
			

	}
	
}
